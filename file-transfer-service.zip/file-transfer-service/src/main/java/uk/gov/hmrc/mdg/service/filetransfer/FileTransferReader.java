package uk.gov.hmrc.mdg.service.filetransfer;

import javax.batch.api.chunk.AbstractItemReader;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.context.JobContext;
import javax.inject.Inject;
import javax.inject.Named;

//import com.byteslounge.cdi.annotation.Property;
//import com.github.fge.jsonschema.main.JsonValidator;

import java.util.Properties;

@Named("fileTransferReader")
public class FileTransferReader extends AbstractItemReader {

    @Inject
    private JobContext jobContext;
	
//	@Inject
//	private JsonValidator jsonValidator;
//	
//	@Inject
//	private MyInterface myInterface;
//    
//    @Property(value = "my.prop", resourceBundleBaseName = "file-transfer")
//    private String myProp;

    private static int count = 0;


    @Override
    public Integer readItem() throws Exception {
        count++;
        
        System.out.println("***********item reader: " + count);
        
//        System.out.println("***********myProp: " + myProp);
//        
//        System.out.println("***********jsonValidator: " + jsonValidator);
//        
//        myInterface.printMe();
        
        if(count == 2) {
            return null;
        }

        Properties pros = BatchRuntime.getJobOperator().getParameters(jobContext.getExecutionId());
        
        //TESTING ERRORS
//        int[] testarray = new int[2];
//        for(int i = 0; i<100; i++)
//        {
//        	System.out.println("Position " + i + ": " + testarray[i]);
//        }
        
        System.out.println("Done..");


        System.out.println("**************file name: " + pros.getProperty("filename"));
        System.out.println("**************file url: " + pros.getProperty("fileurl"));

        System.out.println("Done..");

        return count;
    }
}
