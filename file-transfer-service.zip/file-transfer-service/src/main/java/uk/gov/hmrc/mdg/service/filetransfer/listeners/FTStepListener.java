package uk.gov.hmrc.mdg.service.filetransfer.listeners;

import javax.batch.api.listener.StepListener;

public class FTStepListener implements StepListener {

	@Override
	public void afterStep() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeStep() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
