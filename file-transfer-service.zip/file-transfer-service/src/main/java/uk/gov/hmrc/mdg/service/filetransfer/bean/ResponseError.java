package uk.gov.hmrc.mdg.service.filetransfer.bean;

public class ResponseError {
	
	private String code;
	
	private String reason;

	public ResponseError(String code, String reason) {
		super();
		this.code = code;
		this.reason = reason;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
}
