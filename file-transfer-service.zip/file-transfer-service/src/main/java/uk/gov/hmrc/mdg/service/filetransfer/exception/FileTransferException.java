package uk.gov.hmrc.mdg.service.filetransfer.exception;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.batch.runtime.BatchStatus;

@SuppressWarnings("serial")
public class FileTransferException extends Exception {

	public FileTransferException() {
		// TODO Auto-generated constructor stub
	}

	public FileTransferException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FileTransferException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public FileTransferException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FileTransferException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
	public void FileTransferErrorLog(String jobName, String className, String stepName, long jobId, Exception error)
	{
		Logger.getLogger(className)
		.log(Level.SEVERE, "**********************ERROR*************************");
		Logger.getLogger(className)
		.log(Level.SEVERE, "Error has occured in job " + jobName 
		+ " with ID: " + jobId + " while reading file...");
		Logger.getLogger(className)
		.log(Level.SEVERE, "Failed due to " + error.getMessage() + " from this step " + stepName);
		Logger.getLogger(className)
		.log(Level.SEVERE, "File Transfer will now end with status: " + BatchStatus.FAILED);
		Logger.getLogger(className)
		.log(Level.SEVERE, "Please investigate and re-trigger the job");
		Logger.getLogger(className)
		.log(Level.SEVERE, "****************************************************");
	}

}
