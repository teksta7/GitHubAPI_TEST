package uk.gov.hmrc.mdg.service.filetransfer.listeners;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.batch.api.chunk.listener.ItemProcessListener;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.BatchStatus;
import javax.batch.runtime.context.JobContext;
import javax.batch.runtime.context.StepContext;
import javax.inject.Inject;
import javax.inject.Named;

import uk.gov.hmrc.mdg.service.filetransfer.exception.FileTransferException;

@Named("processListener")
public class FTProcessListener implements ItemProcessListener{

	@Inject
	private JobContext JC;
	
	@Inject
	private StepContext SC;
		
	private int RestartCount = 0;
	
	private long jobID;
	
	private Properties props;
	
	private FileTransferException ft = new FileTransferException();
	
	/*Any clean up needed after the Processor has finished
	Runs on successful completion of the processor component */	
	@Override
	public void afterProcess(Object preProcessedItem, Object postProcessedItem) throws FileTransferException, InterruptedException {
		//cleanup anything from AV
		props = BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()); //Fetch Batch properties for modification
		//Check if file has been processed correctly
		if(preProcessedItem != null & postProcessedItem != null)
		{
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.INFO, "Processor finished");	
		}
		//No file found so check is needed to see if restart is possible via batch props given 
		else if(Integer.parseInt(props.get("restart").toString()) > 0)
		{
			//Convert String value of the restart count to int, Decrement by 1, 
			//Sleep thread to allow any extra code to finish and start new instance of job while marking current instance
			//as COMPLETED(job is shutdown gracefully) as null from Processor is a valid batch scenario(NON-FATAL)
			RestartCount = Integer.parseInt(BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()).getProperty("restart"));
			props.setProperty("restart", String.valueOf(--RestartCount));
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.WARNING, "Cannot process null, restarting gracefully in 5s...");
			Thread.sleep(5000);
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.INFO, "Restarted job successfully, new execution ID assigned: " + BatchRuntime.getJobOperator().start(JC.getJobName(), props));
			JC.setExitStatus("COMPLETED");
		}
		else
		{
			//Null has been returned too many times with no restarts left, Throw exception stating this(triggers onReadError())
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.WARNING, "Restarts for " + JC.getJobName() + " are exausted, throwing error");
			throw new FileTransferException("Restarts have been exhausted due to Processor output being null 3 times");
		}	
	}

	@Override
	public void beforeProcess(Object o) throws FileTransferException {
		//Setup anything needed for AV
		Logger.getLogger(FTProcessListener.class.getName())
		.log(Level.INFO, "Starting processor");		
	}

	@Override
	public void onProcessError(Object preProcessedItem, Exception error) throws FileTransferException {
		///////////////////////////////////////////////////////////////////
		//MAY WANT TO INTEPRET OBJECT TO BE PROCESSED FOR DEBUGGING (WIP)//
		///////////////////////////////////////////////////////////////////
		//Keep track of current job ID
		jobID = JC.getExecutionId();
		Logger.getLogger(FTProcessListener.class.getName())
		.log(Level.INFO, "Current job ID: " + jobID );	
		//Check if restart argument has been given
		if(RestartCount == 0 & (BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()).getProperty("restart") != "0"))
		{
			//Map RestartCount to props value to track restarts and initial assignment of variable
			RestartCount = Integer.parseInt(BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()).getProperty("restart"));
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.INFO, "Initialising auto-restart mechanism");
			props = BatchRuntime.getJobOperator().getParameters(JC.getExecutionId());
		}
		Logger.getLogger(FTProcessListener.class.getName())
		.log(Level.INFO, "Restarts left to use: " + RestartCount);
		//Assess if restart is possible and attempt to restart current job
		switch(RestartCount)
		{		
		case 1: case 2: case 3:
			//Decrement RestartCount by 1, 
			//Mark current job as stopped due to error(Exception is dumped to logs)
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.INFO, "Attempting restart of current job ");
			RestartCount--;
			props.setProperty("restart", String.valueOf(RestartCount));
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.INFO, "Restarted job successfully, new execution ID assigned: " + BatchRuntime.getJobOperator().start(JC.getJobName(), props));
			JC.setExitStatus("STOPPED");
			throw new FileTransferException("Processor component has not finished successfully but has been restarted");
		default:
			//Error handle anything non successful from the Processor component, mark job as failed with no restarts left
			Logger.getLogger(FTProcessListener.class.getName())
			.log(Level.WARNING, "No automatic restarts available, not retrying job automatically");
			ft.FileTransferErrorLog(JC.getJobName() , FTProcessListener.class.getName(), 
					SC.getStepName(), JC.getExecutionId(), error);
			JC.setExitStatus("FAILED");
			throw new FileTransferException("Processor component has not finished successfully, Live service intervention required");
		}

	}

}
