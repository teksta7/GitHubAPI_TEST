package uk.gov.hmrc.mdg.service.filetransfer.rest;

import javax.batch.runtime.BatchRuntime;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.io.IOException;
import java.util.Properties;

import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonValidator;

import uk.gov.hmrc.mdg.service.filetransfer.bean.ResponseError;

import com.fasterxml.jackson.databind.JsonNode;

@Path("file-ready")
public class FileReady {
	
	@Inject
	private JsonValidator jsonValidator;
	
	@Inject
	private JsonNode requestJsonSchema;

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Response handleFileReady(String notification) {
        System.out.println("*****************notification: " + notification);

        JsonNode request = null;
        ProcessingReport report = null;
        
        try {
			request = JsonLoader.fromString(notification);
	        report = jsonValidator.validate(requestJsonSchema, request);
	        
	        System.out.println("*****************result: " + report.isSuccess());
		} catch (IOException | ProcessingException e) {
			System.out.println("Exception occured with message: " + e.getMessage() + ". Returning 500 response back to client.");
        	ResponseError responseError = new ResponseError("INTERNAL_SERVER_ERROR",
        			"File transfer application is currently experiencing problems that require live service intervention.");
        	return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(responseError).type(MediaType.APPLICATION_JSON).build();
		}
        
        if(!report.isSuccess()) {
        	ResponseError responseError = new ResponseError("BAD_REQUEST", "Submission has not passed validation. Invalid JSON payload.");
        	return Response.status(Response.Status.BAD_REQUEST).entity(responseError).type(MediaType.APPLICATION_JSON).build();
        }


        BatchRuntime.getJobOperator().start("filetransfer", buildJobProperties(request));
        
        return Response.status(Response.Status.NO_CONTENT).build();
    }

	private Properties buildJobProperties(JsonNode request) {
		final Properties jobParams = new Properties();
        jobParams.setProperty("filename", request.get("fileName").asText());
        jobParams.setProperty("fileurl", request.get("fileUrl").asText());
		return jobParams;
	}

//  @PUT
//  @Consumes(MediaType.APPLICATION_JSON)
//  public Response handleFileReady(FileReadyNotification notification) {
//
//      final Properties jobParams = new Properties();
//      jobParams.setProperty("filename", notification.getFileName());
//      jobParams.setProperty("fileurl", notification.getFileUrl());
//
//
//      BatchRuntime.getJobOperator().start("filetransfer", jobParams);
//      return Response.status(Response.Status.NO_CONTENT).build();
//  }
}