package uk.gov.hmrc.mdg.service.filetransfer.exception;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import uk.gov.hmrc.mdg.service.filetransfer.bean.ResponseError;

@Provider
public class GenericExceptionMapper implements ExceptionMapper<Throwable>{

	@Override
	public Response toResponse(Throwable throwable) {
		System.out.println("Exception occured with message: " + throwable.getMessage() + ". Returning 500 response back to client.");
		ResponseError responseError = new ResponseError("INTERNAL_SERVER_ERROR",
    			"File transfer application is currently experiencing problems that require live service intervention.");
		throwable.printStackTrace();
    	return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(responseError).type(MediaType.APPLICATION_JSON).build();
	}

}
