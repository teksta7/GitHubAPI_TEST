package uk.gov.hmrc.mdg.service.filetransfer.listeners;

import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.batch.api.chunk.listener.ItemWriteListener;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.BatchStatus;
import javax.batch.runtime.context.JobContext;
import javax.batch.runtime.context.StepContext;
import javax.inject.Inject;
import javax.inject.Named;

import uk.gov.hmrc.mdg.service.filetransfer.exception.FileTransferException;

@Named("writerListener")
public class FTWriterListener implements ItemWriteListener {

	@Inject
	private JobContext JC;

	@Inject
	private StepContext SC;

	private int RestartCount = 0;

	private long jobID;

	private Properties props;

	private FileTransferException ft = new FileTransferException();

	/*
	 * Any clean up needed after the writer has finished Runs on successful
	 * completion of the writer component
	 */
	@Override
	public void afterWrite(List<Object> files) throws FileTransferException, InterruptedException {
		// TODO Auto-generated method stub
		// Can be used for DEBUGGING
		// cleanup anything from AV
		props = BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()); // Fetch Batch properties for
																					// modification
		// Check if files have been written correctly(list should not be null)
		if (files != null) {
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO, "Files written to buckets");
		}
		// No files found so check is needed to see if restart is possible via batch
		// props given
		else if (Integer.parseInt(props.get("restart").toString()) > 0) {
			// Convert String value of the restart count to int, Decrement by 1,
			// Sleep thread to allow any extra code to finish and start new instance of job
			// while marking current instance
			// as COMPLETED(job is shutdown gracefully) as null from writer is a valid
			// batch scenario(NON-FATAL)
			RestartCount = Integer
					.parseInt(BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()).getProperty("restart"));
			props.setProperty("restart", String.valueOf(--RestartCount));
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.WARNING,
					"Cannot process null, restarting gracefully in 5s...");
			Thread.sleep(5000);
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO,
					"Restarted job successfully, new execution ID assigned: "
							+ BatchRuntime.getJobOperator().start(JC.getJobName(), props));
			JC.setExitStatus("COMPLETED");
		} else {
			// Null has been returned too many times with no restarts left, Throw exception
			// stating this(triggers onReadError())
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.WARNING,
					"Restarts for " + JC.getJobName() + " are exausted, throwing error");
			throw new FileTransferException("Restarts have been exhausted due to writer output being null 3 times");
		}
	}

	@Override
	public void beforeWrite(List<Object> files) throws FileTransferException {
		// TODO Auto-generated method stub
		// Can be used for DEBUGGING
//		Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO, "Writing file to buckets...");
	}

	@Override
	public void onWriteError(List<Object> objects, Exception error) throws FileTransferException {
		///////////////////////////////////////////////////////////////////
		// MAY WANT TO INTEPRET LIST TO BE WRITTEN FOR DEBUGGING (WIP)//
		///////////////////////////////////////////////////////////////////
		// Keep track of current job ID
		jobID = JC.getExecutionId();
		Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO, "Current job ID: " + jobID);
		// Check if restart argument has been given
		if (RestartCount == 0
				& (BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()).getProperty("restart") != "0")) {
			// Map RestartCount to props value to track restarts and initial assignment of
			// variable
			RestartCount = Integer
					.parseInt(BatchRuntime.getJobOperator().getParameters(JC.getExecutionId()).getProperty("restart"));
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO, "Initialising auto-restart mechanism");
			props = BatchRuntime.getJobOperator().getParameters(JC.getExecutionId());
		}
		Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO, "Restarts left to use: " + RestartCount);
		// Assess if restart is possible and attempt to restart current job
		switch (RestartCount) {
		case 1:
		case 2:
		case 3:
			// Decrement RestartCount by 1,
			// Mark current job as stopped due to error(Exception is dumped to logs)
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO, "Attempting restart of current job ");
			RestartCount--;
			props.setProperty("restart", String.valueOf(RestartCount));
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.INFO,
					"Restarted job successfully, new execution ID assigned: "
							+ BatchRuntime.getJobOperator().start(JC.getJobName(), props));
			JC.setExitStatus("STOPPED");
			throw new FileTransferException("Writer component has not finished successfully but has been restarted");
		default:
			// Error handle anything non successful from the writer component, mark job
			// as failed with no restarts left
			Logger.getLogger(FTWriterListener.class.getName()).log(Level.WARNING,
					"No automatic restarts available, not retrying job automatically");
			ft.FileTransferErrorLog(JC.getJobName(), FTWriterListener.class.getName(), SC.getStepName(),
					JC.getExecutionId(), error);
			JC.setExitStatus("FAILED");
			throw new FileTransferException("Writer component has not finished successfully, Live service intervention required");
		}

	}

}
