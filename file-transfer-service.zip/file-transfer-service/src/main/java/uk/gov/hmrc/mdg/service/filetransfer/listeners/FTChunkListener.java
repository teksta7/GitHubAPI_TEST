package uk.gov.hmrc.mdg.service.filetransfer.listeners;

import javax.batch.api.chunk.listener.ChunkListener;

public class FTChunkListener implements ChunkListener{

	@Override
	public void afterChunk() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeChunk() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(Exception arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
