package uk.gov.hmrc.mdg.service.filetransfer;

import javax.batch.api.chunk.ItemProcessor;
import javax.inject.Named;

@Named("fileTransferProcessor")
public class FileTransferProcessor implements ItemProcessor {

    @Override
    public Integer processItem(Object o) throws Exception {
        int count = (Integer) o;
        System.out.println("***********item processor: " + count);
        return count;
    }
}
