package uk.gov.hmrc.mdg.service.filetransfer;

import javax.batch.api.chunk.AbstractItemWriter;
import javax.inject.Named;

import java.util.List;

@Named("fileTransferWriter")
public class FileTransferWriter extends AbstractItemWriter {

    @Override
    public void writeItems(List<Object> list) throws Exception {
        for(Object o : list) {
            int count = (Integer) o;
            System.out.println("***********item writer: " + count);
        }
    }
}
